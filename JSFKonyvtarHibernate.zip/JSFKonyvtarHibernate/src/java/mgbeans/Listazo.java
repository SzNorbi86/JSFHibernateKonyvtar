/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mgbeans;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import org.hibernate.Session;
import pojos.Konyv;
import pojos.Tag;

/**
 *
 * @author norbertszilagyi
 */
@ManagedBean
@SessionScoped
public class Listazo {

    private List<Konyv> konyvek;
    private List<Tag> tagok;
    private List<Konyv> konyvek2;
    private Konyv kivalasztottKonyv;
    private Tag kivalasztottTag;

    private String kivalasztottTagId;
    private Map<String, Tag> tagokMap;

    public Map<String, Tag> getTagokMap() {
        return tagokMap;
    }

    public void setTagokMap(Map<String, Tag> tagokMap) {
        this.tagokMap = tagokMap;
    }

    public Listazo() {
        Session session = hibernate.HibernateUtil.getSessionFactory().openSession();
        tagok = session.createQuery("FROM Tag WHERE id>0").list();

        session.close();

        tagokMap = new HashMap<>();
        for (Tag t : tagok) {
            tagokMap.put(Integer.toString(t.getId()), t);
        }

    }

    public void konyvValaszt() {
        kivalasztottTag = tagokMap.get(kivalasztottTagId);
        konyvek = new ArrayList<>(kivalasztottTag.getKonyvs());

    }

    public void elerhetoKonyvek() {
        Session session = hibernate.HibernateUtil.getSessionFactory().openSession();
        konyvek2 = session.createQuery("FROM Konyv WHERE tag.id=0").list();
        session.close();

    }

    public String kolcsonzes(Konyv konyv) {
        kivalasztottKonyv = konyv;
        return "kolcsonzes";
    }

    public String kolcsonzesMent() {
        kivalasztottTag = tagokMap.get(kivalasztottTagId);
        kivalasztottKonyv.setTag(kivalasztottTag);
        Session session = hibernate.HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.update(kivalasztottKonyv);
        session.getTransaction().commit();
        session.close();

        konyvValaszt();
        elerhetoKonyvek();
        return "index";
    }

    public void visszavetMent() {
        kivalasztottTag = tagokMap.get(kivalasztottTagId);
        kivalasztottKonyv.setTag(kivalasztottTag);
        Session session = hibernate.HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.update(kivalasztottKonyv);
        session.getTransaction().commit();
        session.close();

    }

    public void torol(Tag t) {
        Session session = hibernate.HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.delete(kivalasztottKonyv);
        session.getTransaction().commit();
        session.close();
        tagok.remove(t);

    }

    public void tagSzerkeszt(Tag t) {
        kivalasztottTag = t;

    }

    public void tabMegsem() {
        kivalasztottTag = null;

    }

    public void tagMentes() {
        boolean uj = kivalasztottTag.getId() == null;

        Session session = hibernate.HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        if (uj) {
            session.save(kivalasztottTag);

        } else {
            session.update(kivalasztottTag);

        }
        session.getTransaction().commit();
        session.close();
    }
    
    
    public void ujTag() {
        kivalasztottTag= new Tag();
    }

    public List<Konyv> getKonyvek() {
        return konyvek;
    }

    public void setKonyvek(List<Konyv> konyvek) {
        this.konyvek = konyvek;
    }

    public List<Tag> getTagok() {
        return tagok;
    }

    public void setTagok(List<Tag> tagok) {
        this.tagok = tagok;
    }

    public String getKivalasztottTagId() {
        return kivalasztottTagId;
    }

    public void setKivalasztottTagId(String kivalasztottTagId) {
        this.kivalasztottTagId = kivalasztottTagId;
    }

    public Konyv getKivalasztottKonyv() {
        return kivalasztottKonyv;
    }

    public void setKivalasztottKonyv(Konyv kivalasztottKonyv) {
        this.kivalasztottKonyv = kivalasztottKonyv;
    }

    public Tag getKivalasztottTag() {
        return kivalasztottTag;
    }

    public void setKivalasztottTag(Tag kivalasztottTag) {
        this.kivalasztottTag = kivalasztottTag;
    }

    public List<Konyv> getKonyvek2() {
        return konyvek2;
    }

    public void setKonyvek2(List<Konyv> konyvek2) {
        this.konyvek2 = konyvek2;
    }

}
